-- Crear tabla ESCUELA_DEPORTIVA
CREATE TABLE escuela_deportiva (
    id_escuela     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Auto incrementable
    nombre_escuela VARCHAR2(50 BYTE) NOT NULL,
    tipo_escuela   VARCHAR2(30 BYTE) NOT NULL,
    direccion      VARCHAR2(50 BYTE) NOT NULL,
    telefono       INTEGER NOT NULL,
    email          VARCHAR2(30 BYTE) NOT NULL,
    ciudad         VARCHAR2(15 BYTE) NOT NULL,
    region         VARCHAR2(20 BYTE) NOT NULL
);

ALTER TABLE escuela_deportiva ADD CONSTRAINT un_escuela_deportiva_email UNIQUE (email);
ALTER TABLE escuela_deportiva ADD CONSTRAINT un_nombre_escuela UNIQUE (nombre_escuela);

-- Crear tabla SOLICITUD_FINANCIAMIENTO
CREATE TABLE solicitud_financiamiento (
    id_solicitud        INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Auto incrementable
    fecha_solicitud     DATE NOT NULL,
    monto_solicitado    NUMBER(10, 2) NOT NULL,
    estado              VARCHAR2(20 BYTE) NOT NULL,
    tipo_financiamiento VARCHAR2(10 BYTE) NOT NULL,
    esc_deport_id_esc   INTEGER NOT NULL
);

-- Crear clave única compuesta en solicitud_financiamiento
ALTER TABLE solicitud_financiamiento ADD CONSTRAINT un_solicitud_financiamiento UNIQUE (id_solicitud, esc_deport_id_esc);

-- Crear clave foránea en solicitud_financiamiento para escuela_deportiva
ALTER TABLE solicitud_financiamiento
    ADD CONSTRAINT fk_solicitud_financiamiento_escuela FOREIGN KEY (esc_deport_id_esc)
    REFERENCES escuela_deportiva(id_escuela);

-- Crear tabla PERSONAL
CREATE TABLE personal (
    id_personal       INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Auto incrementable
    nombre            VARCHAR2(20 BYTE) NOT NULL,
    apellido          VARCHAR2(20 BYTE) NOT NULL,
    nacionalidad      VARCHAR2(10 BYTE) NOT NULL,
    telefono          INTEGER NOT NULL,
    email             VARCHAR2(30 BYTE) NOT NULL,
    tipo_personal     VARCHAR2(15 BYTE) NOT NULL,
    esc_deport_id_esc INTEGER NOT NULL
);

-- Agregar clave única compuesta en personal
ALTER TABLE personal ADD CONSTRAINT un_personal_escuela UNIQUE (id_personal, esc_deport_id_esc);

ALTER TABLE personal ADD CONSTRAINT un_personal_email UNIQUE (email);
ALTER TABLE personal ADD CONSTRAINT fk_personal_escuela FOREIGN KEY (esc_deport_id_esc)
    REFERENCES escuela_deportiva(id_escuela);

-- Crear tabla ADMINISTRADOR
CREATE TABLE administrador (
    id_personal  INTEGER NOT NULL,
    area_gestion VARCHAR2(20 BYTE) NOT NULL,
    anio_gestion INTEGER NOT NULL,
    id_escuela   INTEGER NOT NULL
);

ALTER TABLE administrador ADD CONSTRAINT pk_administrador PRIMARY KEY (id_personal, id_escuela);
ALTER TABLE administrador ADD CONSTRAINT fk_administrador_personal FOREIGN KEY (id_personal, id_escuela)
    REFERENCES personal(id_personal, esc_deport_id_esc);

-- Crear tabla ASISTENTE
CREATE TABLE asistente (
    id_personal      INTEGER NOT NULL,
    tareas_asignadas VARCHAR2(30 BYTE) NOT NULL,
    horas_semanales  NUMBER(10) NOT NULL,
    id_escuela       INTEGER NOT NULL
);

ALTER TABLE asistente ADD CONSTRAINT pk_asistente PRIMARY KEY (id_personal, id_escuela);
ALTER TABLE asistente ADD CONSTRAINT fk_asistente_personal FOREIGN KEY (id_personal, id_escuela)
    REFERENCES personal(id_personal, esc_deport_id_esc);

-- Crear tabla ENTRENADOR
CREATE TABLE entrenador (
    id_personal            INTEGER NOT NULL,
    especialidad_deportiva VARCHAR2(20 BYTE) NOT NULL,
    certificaciones        VARCHAR2(30 BYTE) NOT NULL,
    anios_experiencia      INTEGER NOT NULL,
    id_escuela             INTEGER NOT NULL
);

ALTER TABLE entrenador ADD CONSTRAINT pk_entrenador PRIMARY KEY (id_personal, id_escuela);
ALTER TABLE entrenador ADD CONSTRAINT fk_entrenador_personal FOREIGN KEY (id_personal, id_escuela)
    REFERENCES personal(id_personal, esc_deport_id_esc);

-- Crear tabla COSTO_OPERACIONAL
CREATE TABLE costo_operacional (
    id_costo                    INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Auto incrementable
    descripcion                 VARCHAR2(40 BYTE) NOT NULL,
    monto                       NUMBER(10, 2) NOT NULL,
    fecha                       DATE NOT NULL,
    id_escuela                  INTEGER NOT NULL,
    id_solicitud                INTEGER NOT NULL,
    solic_financ_esc_dep_id_esc  INTEGER NOT NULL
);

-- Crear clave foránea para costo_operacional hacia escuela_deportiva
ALTER TABLE costo_operacional ADD CONSTRAINT fk_costo_operacional_escuela FOREIGN KEY (id_escuela)
    REFERENCES escuela_deportiva(id_escuela);

-- Crear clave foránea para costo_operacional hacia solicitud_financiamiento
ALTER TABLE costo_operacional ADD CONSTRAINT fk_costo_operacional_solicitud FOREIGN KEY (id_solicitud, solic_financ_esc_dep_id_esc)
    REFERENCES solicitud_financiamiento(id_solicitud, esc_deport_id_esc);

-- Crear tabla INSTALACION_DEPORTIVA
CREATE TABLE instalacion_deportiva (
    id_instalacion     INTEGER GENERATED ALWAYS AS IDENTITY PRIMARY KEY, -- Auto incrementable
    nombre_instalacion VARCHAR2(20 BYTE) NOT NULL,
    tipo_instalacion   VARCHAR2(20 BYTE) NOT NULL,
    capacidad          INTEGER NOT NULL,
    esc_deport_id_esc  INTEGER NOT NULL
);

ALTER TABLE instalacion_deportiva ADD CONSTRAINT fk_instalacion_deportiva_escuela FOREIGN KEY (esc_deport_id_esc)
    REFERENCES escuela_deportiva(id_escuela);





-- INGRESO DE DATOS --




INSERT INTO escuela_deportiva (nombre_escuela, tipo_escuela, direccion, telefono, email, ciudad, region)
VALUES ('Escuela Olimpica', 'Futbol', 'Calle A 123', 987654321, 'contacto@olimpica.cl', 'Santiago', 'Metropolitana');

INSERT INTO escuela_deportiva (nombre_escuela, tipo_escuela, direccion, telefono, email, ciudad, region)
VALUES ('Escuela Andina', 'Basketball', 'Calle B 456', 912345678, 'info@andina.cl', 'Valparaiso', 'Valparaiso');

INSERT INTO escuela_deportiva (nombre_escuela, tipo_escuela, direccion, telefono, email, ciudad, region)
VALUES ('Escuela Cordillera', 'Voleibol', 'Calle C 789', 923456789, 'admin@cordillera.cl', 'Concepcion', 'BioBio');

INSERT INTO escuela_deportiva (nombre_escuela, tipo_escuela, direccion, telefono, email, ciudad, region)
VALUES ('Escuela Pacifico', 'Natacion', 'Calle D 123', 934567890, 'natacion@pacifico.cl', 'La Serena', 'Coquimbo');





INSERT INTO solicitud_financiamiento (fecha_solicitud, monto_solicitado, estado, tipo_financiamiento, esc_deport_id_esc)
VALUES (TO_DATE('2023-06-01', 'YYYY-MM-DD'), 50000, 'Pendiente', 'Publico', 1);

INSERT INTO solicitud_financiamiento (fecha_solicitud, monto_solicitado, estado, tipo_financiamiento, esc_deport_id_esc)
VALUES (TO_DATE('2023-06-15', 'YYYY-MM-DD'), 75000, 'Aprobado', 'Privado', 2);

INSERT INTO solicitud_financiamiento (fecha_solicitud, monto_solicitado, estado, tipo_financiamiento, esc_deport_id_esc)
VALUES (TO_DATE('2023-07-01', 'YYYY-MM-DD'), 60000, 'Rechazado', 'Publico', 3);

INSERT INTO solicitud_financiamiento (fecha_solicitud, monto_solicitado, estado, tipo_financiamiento, esc_deport_id_esc)
VALUES (TO_DATE('2023-07-20', 'YYYY-MM-DD'), 45000, 'Aprobado', 'Publico', 4);





INSERT INTO personal (nombre, apellido, nacionalidad, telefono, email, tipo_personal, esc_deport_id_esc)
VALUES ('Juan', 'Perez', 'Chilena', 987123456, 'jperez@olimpica.cl', 'Entrenador', 1);

INSERT INTO personal (nombre, apellido, nacionalidad, telefono, email, tipo_personal, esc_deport_id_esc)
VALUES ('Maria', 'Gonzalez', 'Chilena', 912345679, 'mgonzalez@andina.cl', 'Asistente', 2);

INSERT INTO personal (nombre, apellido, nacionalidad, telefono, email, tipo_personal, esc_deport_id_esc)
VALUES ('Luis', 'Lopez', 'Argentina', 923456789, 'llopez@cordillera.cl', 'Administrador', 3);

INSERT INTO personal (nombre, apellido, nacionalidad, telefono, email, tipo_personal, esc_deport_id_esc)
VALUES ('Ana', 'Ramirez', 'Peruana', 934567890, 'aramirez@pacifico.cl', 'Entrenador', 4);





INSERT INTO administrador (id_personal, area_gestion, anio_gestion, id_escuela)
VALUES (3, 'Gestion Financiera', 2023, 3);

INSERT INTO administrador (id_personal, area_gestion, anio_gestion, id_escuela)
VALUES (1, 'Gestion Deportiva', 2022, 1);




INSERT INTO asistente (id_personal, tareas_asignadas, horas_semanales, id_escuela)
VALUES (2, 'Apoyo en entrenamientos', 20, 2);

INSERT INTO asistente (id_personal, tareas_asignadas, horas_semanales, id_escuela)
VALUES (4, 'Organizacion de eventos', 30, 4);




INSERT INTO entrenador (id_personal, especialidad_deportiva, certificaciones, anios_experiencia, id_escuela)
VALUES (1, 'Futbol', 'FIFA Coaching', 5, 1);

INSERT INTO entrenador (id_personal, especialidad_deportiva, certificaciones, anios_experiencia, id_escuela)
VALUES (4, 'Natacion', 'FINA Instructor', 7, 4);




INSERT INTO costo_operacional (descripcion, monto, fecha, id_escuela, id_solicitud, solic_financ_esc_dep_id_esc)
VALUES ('Compra de balones', 20000, TO_DATE('2023-08-01', 'YYYY-MM-DD'), 1, 1, 1);

INSERT INTO costo_operacional (descripcion, monto, fecha, id_escuela, id_solicitud, solic_financ_esc_dep_id_esc)
VALUES ('Arriendo de cancha', 50000, TO_DATE('2023-08-15', 'YYYY-MM-DD'), 2, 2, 2);

INSERT INTO costo_operacional (descripcion, monto, fecha, id_escuela, id_solicitud, solic_financ_esc_dep_id_esc)
VALUES ('Compra de trajes', 30000, TO_DATE('2023-08-20', 'YYYY-MM-DD'), 4, 4, 4);

INSERT INTO costo_operacional (descripcion, monto, fecha, id_escuela, id_solicitud, solic_financ_esc_dep_id_esc)
VALUES ('Mantenimiento de piscina', 45000, TO_DATE('2023-09-01', 'YYYY-MM-DD'), 4, 3, 3);





INSERT INTO instalacion_deportiva (nombre_instalacion, tipo_instalacion, capacidad, esc_deport_id_esc)
VALUES ('Cancha Principal', 'Futbol', 500, 1);

INSERT INTO instalacion_deportiva (nombre_instalacion, tipo_instalacion, capacidad, esc_deport_id_esc)
VALUES ('Gimnasio', 'Basketball', 300, 2);

INSERT INTO instalacion_deportiva (nombre_instalacion, tipo_instalacion, capacidad, esc_deport_id_esc)
VALUES ('Pista de Voleibol', 'Voleibol', 200, 3);

INSERT INTO instalacion_deportiva (nombre_instalacion, tipo_instalacion, capacidad, esc_deport_id_esc)
VALUES ('Piscina', 'Natacion', 150, 4);




